# FC 27 Hub para Android (projeto pronto para gerar APK)

Este pacote contém o aplicativo web e um fluxo automatizado para compilar um APK Android de teste. **Ele ainda não contém um APK compilado**, porque este ambiente não possui Android SDK/Gradle instalado. O workflow do GitHub Actions faz a compilação em um runner Android/Java adequado.

## Gerar o APK pelo GitHub (recomendado se você está usando apenas o celular)
1. Extraia o ZIP.
2. Crie um repositório no GitHub e envie todos os arquivos e pastas deste projeto para a branch `main`.
3. No repositório, abra a aba **Actions** e habilite workflows se solicitado.
4. Execute **Build FC 27 Hub APK** usando **Run workflow**. Também executa quando há push na branch `main`.
5. Quando terminar com sucesso, abra a execução do workflow e baixe o artefato **FC-27-Hub-debug-APK**.
6. Extraia o artefato e toque em `app-debug.apk` no Android. Se o Android pedir, permita a instalação para o aplicativo usado para abrir o arquivo. Instale apenas APKs de projetos/fontes em que confia.

## Compilar localmente
Requisitos: Node.js 22+, Android Studio/Android SDK e Java 21. Na pasta do projeto:

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

O APK de depuração fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

## O que é este APK
É um APK de depuração, adequado para teste e instalação direta. Não é uma versão de lançamento assinada com uma chave privada própria nem publicado na Play Store.

## Dados
A amostra inicial tem 30 registros e não representa o banco completo. A aplicação aceita importação CSV local. Verifique a fonte dos dados e não trate potencial/idade/valor ausentes como conhecidos.


Atualização de filtros: a tela Jogadores inclui filtros por gênero, liga e clube. Para que funcionem, os registros importados devem incluir as colunas `gender`, `league` e `club`; os filtros de liga e clube são montados a partir dos dados carregados. Esta atualização não inclui automaticamente a base completa de jogadores.
